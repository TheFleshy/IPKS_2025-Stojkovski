function moveAndScaleCircles(){
    let circle = document.getElementsByClassName('circle')

    for (let i=0; i<circle.length; i++){
        let leftPosition =0
        let scale = 1;
        let interval = setInterval(() => {
            leftPosition += 5
            scale += 0.01

            circle[i].style.left = `${leftPosition}px`
            circle[i].style.transform = `scale(${scale})`

            if (leftPosition >= 400){
                clearInterval(interval)
            }
        }, 50)
    }
}

function moveAndScaleCirclesWithAnimeJS(){
    anime({
      targets: '.circle',
      translateX: 400,
      scale: 1.5,
      duration: 3000,
      easing: 'easeInOutQuad',
      delay: anime.stagger(500)
    })
}

window.onload = function (){
    moveAndScaleCircles();
    moveAndScaleCirclesWithAnimeJS();
}

