const box = document.querySelector('.box')
let postion = 0;

let interval = setInterval(() => {
    postion += 2 // Move 2px per frame
    box.style.transform = `translateX (${postion}px)`
    if (postion >= 300){ // stop at 300px
        clearInterval(interval)
    }
}, 20) // Run every 20ms (50 frames per second)


//Function to display a message after 3 seconds
function showMessage(){
    const messageElement = document.getElementById('message')
    messageElement.textContent = "This message appeared after a 3-second delay!"
}
// Schedule the message to appear
setTimeout(showMessage, 3000)