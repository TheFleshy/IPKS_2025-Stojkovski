let counter = 0
let kodovi = [];
function dodaj(){

    let name = document.getElementById("name").value
    let item = document.getElementById("item").value
    let code = document.getElementById("code").value
    let desc = document.getElementById("desc").value
    let price = document.getElementById("price").value
    var voKoja = document.getElementById("used").value

    if (!name || !item || !code || !desc || !price){
        alert("Vnesi gi site polinja!")
        return
    }

    if (kodovi.includes(code)) {
        alert("Veke postoi toj kod")
        return;
    }
    kodovi += code

    if(price < 0){
        alert("Vrednosta mora da bide pogolema od 0")
        return;
    }

    var katalonskiBroj = document.getElementById("code").value

    let filteredKatalonskiBroj = '';
    for (let i = 0; i < katalonskiBroj.length; i++) {
        if (!(katalonskiBroj[i] >= '0' && katalonskiBroj[i] <= '9') && katalonskiBroj[i] !== '!') {
            filteredKatalonskiBroj += katalonskiBroj[i];
        }
    }

    // console.log(filteredKatalonskiBroj);


    let zgolemenaOglasena = (parseFloat(price) * 1.1)

    var usedContainer = document.getElementById("used_cont")
    var unusedContainer = document.getElementById("unused")


    if(voKoja === "used"){
        var tabela = "<td>"+name+"</td>" + "<td>"+item+"</td>"+ "<td>"+zgolemenaOglasena+"</td>"+ "<td>"+code+"</td>"+ "<td>"+filteredKatalonskiBroj+"</td>"+ "<td>"+"<button onclick='sold(this)'> Sold </button>"+"</td>"
        usedContainer.innerHTML += tabela
    }

    if(voKoja === "unused"){
        var tabelaa = "<td>"+name+"</td>" + "<td>"+item+"</td>"+ "<td>"+zgolemenaOglasena+"</td>"+ "<td>"+code+"</td>"+ "<td>"+filteredKatalonskiBroj+"</td>"+ "<td>"+"<button onclick='sold(this)'> Sold </button>"+"</td>"
        unusedContainer.innerHTML += tabelaa
    }
    counter++
    document.getElementById('counter').textContent = counter;

}

function sold(button){
    let red = button.parentElement.parentElement
    red.style.background = "yellow"
    button.remove()
    counter--
    document.getElementById('counter').textContent = counter;
}




