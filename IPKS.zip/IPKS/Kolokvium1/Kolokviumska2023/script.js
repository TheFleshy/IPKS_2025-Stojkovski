let activeCount = 0;
function addItem(){
    var name = document.getElementById('namesurname').value
    var item = document.getElementById('item').value
    var price  = document.getElementById('price').value
    var code  = document.getElementById('item-code').value
    var number = document.getElementById('item-desc').value
    var used = document.getElementById('mySelect').value
    if (!name || !item || !code || !price) {
        alert("Please fill in all required fields!");
        return;
    }

    var table = used === "never-used" ? document.getElementById('unusedTable') : document.getElementById('usedTable');

    for (let i=1; i<table.rows.length; i++){
        const existingCode = table.rows[i].cells[3].textContent;
        if (existingCode === code){
            alert("greska, go ima kodot")
            return;
        }
    }

    var newRow = table.insertRow();

    var nameCell = newRow.insertCell();
    nameCell.textContent = name;

    var itemCell = newRow.insertCell();
    itemCell.textContent = item;

    var priceCell = newRow.insertCell();
    var increasedPrice = (parseFloat(price) * 1.1)
    priceCell.textContent = increasedPrice;

    var codeCell = newRow.insertCell();
    codeCell.textContent = code;

    var numberCell = newRow.insertCell();
    var filteredCode = code.replace(/[0-9!]/g, '');
    numberCell.textContent = filteredCode;

    var actionsCell = newRow.insertCell();
    var soldButton = document.createElement('button');
    soldButton.textContent = 'Sold';
    soldButton.onclick = function () {
        markSold(soldButton);
    };
    actionsCell.appendChild(soldButton);

    activeCount++;
    if (!isNaN(activeCount)){
        document.getElementById('activeCount').textContent = activeCount;
    }
}
function markSold(button) {
    var row = button.parentElement.parentElement;
    row.style.background = "yellow"
    button.style.display = "none";
    if (activeCount > 0) {
        activeCount--;
        document.getElementById('activeCount').textContent = activeCount;
    }

}
