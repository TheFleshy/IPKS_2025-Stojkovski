let global = 0;

function najavi() {
    var imeprezime = document.getElementById("imeprezime").value
    var oznaka = document.getElementById("oznaka").value
    var koordinati = document.getElementById("koordinati").value
    var radius = document.getElementById("radius").value
    var visina = document.getElementById("visina").value
    var tip = document.getElementById("tip").value

    if (!imeprezime || !oznaka || !koordinati || !radius || !visina || !tip){
        alert("Vnesi gi site polinja")
    }

    let parseRad = parseInt(radius)
    let parseHeight = parseInt(visina)

    var oznakaPattern = /^Z3-UNR-\d{4}$/;    //todo ovoa kako da go napraam bez jquerry MORASE GPT

    if (parseRad > 500 || parseHeight > 150) {
        alert("Radiusot ima pogolema vrednost od 500 metri i visinata nadminuva 150m")
        return
    }

    if (!oznakaPattern.test(oznaka)) {
        alert("Ознаката не е валидна. Форматот треба да биде Z3-UNR-четири броеви.");
        return;
    }

    let Cards = document.getElementById("cards");
    let createdCard = document.createElement("li")
    if (tip === "Едрилица"){
        createdCard.style.border = "2px solid black"
    }else if (tip === "Дрон"){
        if (parseRad === parseHeight){
            createdCard.style.border = "2px solid black"
        }
    }
    createdCard.innerHTML = "<p>" + imeprezime + ", " + oznaka + "</p>" + "<p>" + "Радиус: " + radius + ", " + "Висина: " +visina + "</p>" + "<p>" + tip + "</p>" +
        "<button onclick='Confirm(this)'>Потврди</button><button onclick='Cancel(this)'>Откажи</button>";
    Cards.append(createdCard);

    let counter = document.getElementById("activeCount")
    global++;
    counter.innerHTML = global

}

function Confirm(btn){
    let bg = btn.parentNode;
    bg.style.background="lightgreen";
}

function Cancel(btn){
    let bg = btn.parentNode;
    bg.style.display = "none"
}
// function update(obj) {
//     var redica = obj.parentNode
//     var kelii = redica.getElementsByTagName("p")
//     kelii[kelii.length-1].innerHTML = "<button onclick='sold(this)'>Sold</button><button onclick='save(this)'>Save</button>"
//     for (var i=0; i<(kelii.length-1); i++){
//         kelii[i].innerHTML = "<input type='text' value='"+kelii[i].innerHTML+"'>"
//     }
// }

function save(obj){
    var redica = obj.parentNode.parentNode
    var kelii = redica.getElementsByTagName("p")
    kelii[kelii.length-1].innerHTML = "<button onclick='sold(this)'>Sold</button><button onclick='update(this)'>Update</button>"
    for (var i=0; i<(kelii.length-1); i++){
        var vrednost = kelii[i].getElementsByTagName("input")[0].value
        kelii[i].innerHTML = vrednost
    }
}




//TODO NEZNAM DA NAPRAVAM ZA AKO 4 CIFRI OD OZNAKATA SE ISTI DA NE VAZAT PRAVILATA DEKA MORA DA BIDE MAX 500 I MAX 150
// let match = oznaka.match(oznakaPattern);  //todo ovoa kako da go napraam bez jquerry MORASE GPT
// let isSameDigits = match && match[1].split('').every(digit => digit === match[1][0]); // TODO: KAKO OVOA ISTO DA GO SREDAM MORASE GPT
// if (!isSameDigits) {}
