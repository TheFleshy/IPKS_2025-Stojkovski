var number_cards = 0
function submit() {
    var name = document.getElementById("name").value
    var amount = document.getElementById("amount").value
    var code = document.getElementById("code").value
    var comb = document.getElementById("combination").value
    var bonus = document.getElementById("bonus").value

    if (!name || !amount || !code || !comb){
        alert("NE se vneseni site polinja")
        return
    }

    var card = document.getElementById(code)
    if (card != null){
        alert("Kodot vekje postoi!")
        return;
    }

    for (var i=0; i<10; i++){
        if (code.indexOf(i)!=-1){ //najde brojka na nekoja pozicija
            alert("Nevalidne kod")
            return;
        }
    }

    if (code.indexOf("!")!=-1 || code.indexOf("%")!=-1){
        alert("Nevaliden kod")
        return;
    }

    comb = comb.split(",")
    var combination_str = ""
    for (var i=0; i<7; i++){
        combination_str += "<p class='krug'>"+comb[i]+"</p>"
    }
    var new_card = "<div class='karticka'><p>Name: "+name+"</p><p>Code: "+code+"</p><div>Combination: "+combination_str+"</div><p class='amount'>Amount: "+amount+"</p></div>"
    var cards = document.getElementById("cards")
    cards.innerHTML += new_card
    number_cards += 1

}

function get_comb() {
    if (number_cards < 5){
        return
    }

    var combination_str = ""
    for (var i=0; i<7; i++){
        var broj = parseInt(Math.random()*31+1)
        combination_str += "<p class='krug'>"+broj+"</p>"
    }
    var win_comb = document.getElementById("win_com")
    win_comb.innerHTML += combination_str

    check_combinations()
}

function check_combinations() {
    var win_comb = document.getElementById("win_com")
    win_comb = win_comb.getElementsByClassName("krug")

    var cards = document.getElementById("cards")
    cards = cards.getElementsByClassName("karticka")

    for (var i=0; i<5; i++){
        var card_comb = cards[i].getElementsByClassName("krug")
        var dobitni =0
        for (var j=0; j<7; j++){
            for (var k=0; k<7; k++){
                if (win_comb[j].innerHTML == card_comb[k].innerHTML){
                    dobitni+=1
                }
            }
        }
        if (dobitni<=3){
            cards[i].style.background = "yellow"
        }
        else if(dobitni<=5){
            cards[i].style.background = "blue"
        }
        else{
            cards[i].style.background = "green"
        }
        var bonus = cards[i].getAttribute("title")
        var card_total_win = dobitni*30
        if (bonus == "yes"){
            card_total_win += 500
        }
        var uplata = cards[i].getElementsByClassName("amount")[0].innerHTML.split(":")[1]
        card_total_win += parseInt(uplata)
        cards[i].getElementsByClassName("win")[0].innerHTML = card_total_win
        cards[i].innerHTML += "<button onclick='remove(this)'>Sold</button>"

    }

    /*

     */
}

function remove(obj){
    var element = obj.parentNode
    element.remove()
}