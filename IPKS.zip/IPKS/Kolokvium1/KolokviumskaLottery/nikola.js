let totalWin = 0
let usedCode = []
let counter = 0
let objects = {}
let objCount = 0
function add(){
    let name = document.getElementById("name").value
    let amount = parseInt(document.getElementById("amount").value)
    let code = document.getElementById("code").value
    let comb = document.getElementById("combination").value
    let bonus = document.getElementById("bonus").value

    let combination = comb.split(",")

    if(name.length === 0 || amount.length === 0 || code.length === 0 || combination === 0){
        alert("VNESETE GI SITE PODATOCI")
    }
    else{

        if(usedCode.includes(code)){
            alert("KODOT VEKE POSTOI")
        }
        else{
            usedCode[usedCode.length] = code

            code = code.replaceAll("!", "")
            code = code.replaceAll("%", "")
            for(let i = 0; i < 10; i++){
                code = code.replaceAll(i, "")
            }

            let str = ""
            for(let i = 0; i < 7; i++){
                str += "<p class = 'circle'>" + combination[i] + "</p>"
            }

            let string = "<div class = 'card' title = " + bonus + "><p>Name: " + name + " </p><p>Code: " + code + "</p><div class = line>Combination: " + str + "</div><p class = 'cena'>Initial amount: " + amount + "</p><p>Total win: <span id = 'win'></span></p></div>"
            let div = document.getElementById("cards")
            div.innerHTML += string
            objects[objCount] = combination
            objCount += 1
            counter += 1

            if(counter > 4){
                let button = document.getElementById("getWeekly")
                button.removeAttribute("disabled")
            }
        }
    }
}
function getWeekly(){

    let element = document.getElementById("getWeekly")
    element.setAttribute("disabled", "disabled")

    let area = document.getElementById("winning-combination")
    let temp = []
    let win = []
    for(let i = 0; i < 7; i++){
        let num = Math.floor((Math.random() * 31) + 1)
        win[i] = num
        temp += "<p class = 'circle'>" + num + "</p>"
    }
    area.innerHTML += temp

    let k = document.getElementById("cards").getElementsByClassName("card")
    for(let i = 0; i < k.length; i++){
        let comb = objects[i]
        for(let j = 0; j < 7; j++){
            comb[j] = parseInt(comb[j])
        }
        let back = k[i]
        let correct = 0
        for(let j = 0; j < 7; j++){
            for(let l = 0; l < 7; l++){
                if(win[j] === comb[l]){
                    correct += 1
                }
            }
        }
        if(correct <= 3){
            back.style.background = "yellow"
        }
        else if(correct <= 5){
            back.style.background = "lightblue"
        }
        else{
            back.style.background = "green"
        }
        let text = k[i].querySelector("#win")
        let cena = k[i].querySelector(".cena")
        cena = cena.textContent.split(" ")[2]
        cena = parseInt(cena)
        cena += correct * 30

        if(k[i].getAttribute("title") === "Yes"){
            cena += 500
        }
        text.innerHTML = cena
        totalWin += cena
        let total = document.getElementById("total")
        total.innerHTML = totalWin

        let getPaid = "<button onclick = 'deleteCard(this)'>Get Paid</button>"
        k[i].innerHTML += getPaid
    }

}
function deleteCard(obj){
    let kid = obj.parentNode
    let cena = kid.querySelector("#win").textContent
    cena = parseInt(cena)
    kid.parentNode.removeChild(kid)
    let total = document.getElementById("total")
    let tmp = parseInt(total.textContent)
    total.innerHTML = tmp - cena
}