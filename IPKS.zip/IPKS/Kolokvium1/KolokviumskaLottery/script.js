let kodovi = [];
let totalWin = 0;

function dodadi() {
    var namesurname = document.getElementById("namesurname").value
    var amount = document.getElementById("amount").value
    var code = document.getElementById("code").value
    var comb = document.getElementById("comb").value

    if (!namesurname || !amount || !code || !comb) {
        alert("Vnesi gi site polinja !")
        return
    }

    // var proverka = document.getElementById(code)
    // if (proverka != null){
    //     alert("Veke postoi taa sifra")
    //     return;
    // }
    if (kodovi.includes(code)) {
        alert("Veke postoi toj kod")
        return;
    }
    kodovi += code

    for (let i = 0; i < 10; i++) {
        if (code.indexOf(i) != -1) {
            alert("NEVALIDEN KOD")
            return;
        }
    }
    if (code.indexOf("!") != -1 || code.indexOf("%") != -1) {
        alert("NEVALIDEN KOD")
        return;
    }


    var cardContainer = document.getElementById("cards")
    let card = "<div class='krugcinaa'><p>" + "Name: " + namesurname + "</p>" + "<p>" + "Code: " + code + "</p>" + "<p class='kombinacija'>" + "Combination: " + comb + "</p>" + "<p>" + "Initial amount: " + amount + "</p>" + "<p>" + "Total win: " + "0" + "</p>" +
        "<button onclick='getPaid(this)'>Get paid</button> </div>>"
    cardContainer.innerHTML += card





}

function generira() {
    var randomi = document.getElementById("random_numb")
    randomi.innerHTML = ""
    let praznaNiza = []

    for (var i = 0; i < 7; i++) {
        var randomNum = parseInt((Math.floor(Math.random() * 31) + 1))
        let exist = document.getElementById(randomNum);
        if (exist != null) {
            i--;
            continue;
        }
        praznaNiza[i] = randomNum
        randomi.innerHTML += "<p class='krug' id='" + randomNum + "'> " + randomNum + "</p>";


    }
}

function check_combinations() {
    let karticki = document.getElementById("cards").getElementsByClassName("krugcinaa")

    for (let l = 0; l < karticki.length; l++) {
        let karticka = karticki[l].getElementsByClassName("kombinacija").
        console.log(karticka)
        for (let i = 0; i < 7; i++) {
            for (let j = 0; j < 7; j++) {

            }

        }
    }
}


function getPaid(obj) {
    let row = obj.parentElement
    // row.style.background = "grey"
    row.remove()

}