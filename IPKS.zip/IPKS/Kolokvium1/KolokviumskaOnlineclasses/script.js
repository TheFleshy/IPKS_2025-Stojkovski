let counter = 0;
function Add(){

    var imeprezime = document.getElementById("imeprezime").value
    var email = document.getElementById("email").value
    var age = document.getElementById("age").value
    var username = document.getElementById("username").value
    var password = document.getElementById("password").value
    var role = document.getElementById("role").value

    if (!imeprezime || !email|| !age || !username|| !password || !role){
        alert("Vnesi gi site podatoci!")
        return
    }

    if (password.length < 10) {
        alert("Лозинката мора да има најмалку 10 карактери!");
        return;
    }

    if (age < 18 && role === "teacher"){
        alert("Korisnikot e pomal od 18 i nemoze da bide profesor!")
        return;
    }

    let users = document.getElementById("table")
    for (let i=1; i<users.rows.length; i++){
        const existingCode = users.rows[i].cells[1].textContent;
        if (existingCode === username){
            alert("greska, go ima toj username")
            return;
        }
    }

    let hasUppercase = false;
    let hasDigit = false;

    for (let i = 0; i < password.length; i++) {
        let char = password[i];
        if (char >= 'A' && char <= 'Z') {
            hasUppercase = true;
        }
        if (char >= '0' && char <= '9') {
            hasDigit = true;
        }
    }

    if (!hasUppercase || !hasDigit) {
        alert("Лозинката мора да содржи барем една голема буква и една бројка!");
        return;
    }

    let createUser = document.createElement("tr")

    createUser.innerHTML = "<td>"+imeprezime+"</td>" + "<td>"+username+"</td>" + "<td>"+email+"</td>" + "<td>"+age+"</td>" + "<td>"+role+"</td>" + "<td>"+"</td>"
    if (role === "teacher"){
        createUser.innerHTML = "<td>"+imeprezime+"</td>" + "<td>"+username+"</td>" + "<td>"+email+"</td>" + "<td>"+age+"</td>" + "<td>"+role+"</td>" + "<button onclick='Confirm(this)'>Hire</button>"
    }
    users.append(createUser)

    if (role === "teacher"){
        counter++
        if (!isNaN(counter)){
            document.getElementById("counter").textContent = counter
        }
    }


    let red = users.nextSibling.textContent
    if (role === "teacher"){
        createUser.style.background = "green"
    }
    if(role === "student"){
        createUser.style.background = "aqua"
    }


}
function Confirm(button){
    let row = button.parentElement
    row.style.background = "grey"
    button.remove()
    counter--
    if (!isNaN(counter)){
        document.getElementById("counter").textContent = counter
    }
}