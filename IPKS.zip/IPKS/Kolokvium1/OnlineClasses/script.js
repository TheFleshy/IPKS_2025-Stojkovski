let counter = 0;
let korisnici = []
function dodadi() {

    let name = document.getElementById("name").value
    let email = document.getElementById("email").value
    let age = document.getElementById("age").value
    let username = document.getElementById("username").value
    let password = document.getElementById("password").value
    let role = document.getElementById("role").value


    if (!name || !email || !age || !username || !password){
        alert("Vnesi gi site polinja!")
    }

    if (korisnici.includes(username)) {
        alert("Veke postoi toj korisnik!")
        return;
    }
    korisnici += username

    if (password < 10){
        alert("Mora lozinkata da ima 10 znaci!")
        return;
    }

    let hasUppercase = false;
    let hasDigit = false;

    for (let i=0; i<password.length; i++){
        let char = password[i];
        if (char >= 'A' && char <= 'Z'){
            hasUppercase = true
        }
        else if (char >= 1 && char <= 9){
            hasDigit = true
        }
    }

    if (!hasDigit || !hasUppercase){
        alert("Lozinkata mora da sodrzi barem edna golema bukva i eden broj!")
        return;
    }

    if (role === "teacher" && age < 18){
        alert("Toj korisnik nema 18 i nemoze da bide nastavnik !")
        return;
    }

    var tabelaContainer = document.getElementById("tabela")

    if (role === "teacher"){
        var tabela =  "<tr id='boja'>" +
            "<td>"+name+"</td>" + "<td>"+username+"</td>"+"<td>"+email+"</td>" + "<td>"+age+"</td>"+"<td>"+role+"</td>" + "<td>"+"<button onclick='brisi(this)'> Hire </button>"+"</td>" +
        "</tr>"
        tabelaContainer.innerHTML += tabela

        var redOboen = document.getElementById("boja")
        redOboen.style.background = "lightgreen"

    }


    if (role === "student"){
        var tabelaStudent = "<tr id='bojaStudent'>" + "<td>"+name+"</td>" + "<td>"+username+"</td>"+"<td>"+email+"</td>" + "<td>"+age+"</td>"+"<td>"+role+"</td>" + "</tr>"
        tabelaContainer.innerHTML += tabelaStudent

        var redOboenS = document.getElementById("bojaStudent")
        redOboenS.style.background = "lightblue"

    }

    if (role === "teacher"){
        counter++
        if (!isNaN(counter)){
            document.getElementById("counter").textContent = counter
        }
    }

}

function brisi(button){
    let row = button.parentElement.parentElement
    row.style.background = "grey"
    button.remove();
    counter--
    if (!isNaN(counter)){
        document.getElementById("counter").textContent = counter
    }
}