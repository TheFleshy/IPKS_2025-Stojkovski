function passed(){
    var table = document.getElementById("studenti");
    var rows = table.getElementsByTagName("tr");
    var results = [];
    for (let i=0; i<rows.length; i++){
        var cells = rows[i].getElementsByTagName("td");
        var points = parseInt(cells[2].textContent);
        results.push(points);
        if (results[i] >=50){
            rows[i].style.background = "green"
        }
    }
}

function failed(){
    var table = document.getElementById("studenti");
    var rows = table.getElementsByTagName("tr");
    var results = [];
    for (let i=0; i<rows.length; i++){
        var cells = rows[i].getElementsByTagName("td");
        var points = parseInt(cells[2].textContent);
        results.push(points);
        if (results[i] <50){
            rows[i].style.background = "red"
        }
    }
}

function clearColors(){
    var table = document.getElementById("studenti");
    var rows = table.getElementsByTagName("tr");
    for (let i=0; i<rows.length; i++){
        rows[i].style.background = ""
    }
}