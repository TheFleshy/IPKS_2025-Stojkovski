function calculate(){
    var equation = document.getElementById("equation").value
    var text = equation.split(" ")
    for (let i=0; i<text.length; i++){
        if (text[i] === "one"){
            text[i] = 1;
        }else if(text[i] === "two"){
            text[i] = 2;
        }else if(text[i] === "three"){
            text[i] = 3;
        }else if(text[i] === "four"){
            text[i] = 4;
        }else if(text[i] === "five"){
            text[i] = 5;
        }else if(text[i] === "six"){
            text[i] = 6;
        }else if(text[i] === "seven"){
            text[i] = 7;
        }else if(text[i] === "eight"){
            text[i] = 8;
        }else if(text[i] === "nine"){
            text[i] = 9;
        }else if(text[i] === "zero"){
            text[i] = 0;
        }

        if (text[i] === "plus"){
            text[i] = '+';
        }else if (text[i] === "minus"){
            text[i] = '-'
        }else if (text[i] === "times"){
            text[i] = '*'
        }else if (text[i] === "divided_by"){
            text[i] = '/'
        }

        let j=0;
        for (let i=0; i<text.length; i++){
            if (text[i] === '*' || text[i] === '/'){
                if (!isNaN(text[i-1]) && !isNaN(text[i+1])){
                    if (text[i] === '*'){
                        let result = text[i-1] * text[i+1];
                        text[j] = result;
                        j++;
                    }else {
                        let result = text[i-1] / text[i+1];
                        text[j] = result;
                        j++;
                    }
                    i+=2;
                }
            }else {
                j++;
            }
        }
        console.log(text);
    }


}