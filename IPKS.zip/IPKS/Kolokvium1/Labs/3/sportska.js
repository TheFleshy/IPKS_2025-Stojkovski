function team(ime, sifra){
    this.ime = ime;
    this.sifra = sifra;
    this.golovi = [];
}

var ekipi = [];

var string = prompt("Vnesi tim")
while(string !== '@'){
    string = string.split(':')
    ime = string[0]
    sifra = string[1]
    ekipa = new team(ime, sifra)
    ekipi[sifra] = ekipa
    string = prompt("Vnesi tim")
}

var utakmici = prompt("Vnesi utakmici")
while(utakmici !== '@'){
    utakmici = utakmici.split(';')

    utakmici[0] = utakmici[0].split(':')
    utakmici[1] = utakmici[1].split(':')

    var sifra1 = utakmici[0][0]
    var sifra2 = utakmici[0][1]

    var golovi1 = utakmici[1][0]
    var golovi2 = utakmici[1][1]

    ekipi[sifra1].golovi.push(parseInt(golovi1))
    ekipi[sifra2].golovi.push(parseInt(golovi2))

    utakmici = prompt("Vnesi utakmici")
}

for (let i=0; i<ekipi.length; i++){
    var tim = ekipi[i];
    if (tim){
        console.log(tim)
        let info_za_tim = ''
        info_za_tim += 'Ime: ' + tim.ime + ', Sifra: ' + tim.sifra + ', Golovi: ' + tim.golovi + '<br>';
        document.write(info_za_tim)
    }
}
