//trkite : od i=3 do length-1
// id,ime,prezime,trka1,trka2,trkaN;id2,ime2,prezime2,trka1,trka2,trka3,trkaN;
// 1,bojan,spasovski,3,4,5,12,1;21,Andrej,Stojkovski,3,1,6,2;3,Stefan,Lazarov,1,3,5
let string = prompt("Vnesi go celiot string")
string = string.split(';')

var najmalAverage = 100000
var covek
string.forEach((trkac) =>{
    trkac = trkac.split(',')

    var sumaTrki = 0
    var brojTrki = trkac.length - 3
    for(let i = 3; i<trkac.length; i++){
        sumaTrki += parseInt(trkac[i])
    }
    momentalenAvg = sumaTrki / brojTrki
    najmalAverage = Math.min(momentalenAvg, najmalAverage)
    covek = trkac
})
document.write('id: ' + covek[0] + ', ime: ' + covek[1] + ', prezime: ' + covek[2] + '' +
    '<br>Najmal prosek:'+najmalAverage)

