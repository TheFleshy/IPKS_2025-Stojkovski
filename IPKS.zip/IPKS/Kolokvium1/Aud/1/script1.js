//todo: Confirm Box

var r = confirm("Press the button")

if (r == true){
    x = "You pressed OK \n"
}else {
    x = "You pressed Cancel!"
}

document.write(x)
document.write("\n")
console.log(x)


//todo: Promt Box

var person = prompt ("Please enter the you name", "Harry Potter")
if (person != null){
    document.write("Hello " + person + " How are you today?")
}


//todo: Zadaca 1 - Max od dvja broja vneseni od tastatura

var a = prompt("Vnesete vrednost za a: ")
var b = prompt("Vnesete vrednost za b: ")
a = parseInt(a)
b = parseInt(b)
if (!isNaN(a) && !isNaN(b)){  // proveruva dali se broevi !
    if (a > b){
        document.write("Vrednosta na MAX e: " + a)
    }else {
        document.write("Vrednosta na MAX e: " + b)
    }
}else {
    document.write("Ne ste vnesile celosen broj !")
}


//todo: Zadaca 2 - Proverka dali godinata e prestapna ili ne i pecate poraka

var number = prompt("Vnesete ja godinata: ")
number = parseInt(number)
if (!isNaN(number)){
    if ((number % 4 == 0 && number%100 != 0) || number%400 == 0){
        document.write(number + " e prestapna !")
    }else {
        document.write(number + " ne e prestapna!")
    }
}else {
    document.write("Ne ste vnesile celosen broj !")
}


//todo: Zadaca 3 - Vnesuvat se koordinati na tocka, da se opredele u koj kvadrant pripaga, ako e na kooridnaten pocetok ispeacti poraka

var number1 = prompt("Vnesete ja prvata koordinata: ")
var number2 = prompt("Vnesete ja vtorata koordinata: ")
x = parseInt(number1)
y = parseInt(number2)
if (!isNaN(number1) && !isNaN(number2)){
    if (x>0){
        if (y > 0){
            document.write("Tockata pripagja na prv kvadrant!")
        }
        else if (y < 0){
            document.write("Tockata pripagja na cetvrt kvadrant!")
        }else {
            document.write("Poz. x oska\n")
        }
    }else if (x < 0){
        if (y > 0){
            document.write("Tockata pripagja na vtor kvadrant!")
        }else if (y < 0){
            document.write("Tockata pripagja na tret kvadrant")
        }else {
            document.write("Poz. x oska\n")
        }
    }else {
        if (y > 0){
            document.write("Poz. y oska.\n")
        }else if (y < 0){
            document.write("Poz. y oska.\n")
        }else {
            document.write("Koordinaten pocetok!\n")
        }
    }
}else {
    document.write("Ne ste vnele celosni broevi!")
}


//todo: Zadaca 4 - Vneseni poeni na ispit da dade ocenka

var poeni = prompt("Vnesete gi boenie: ")
poeni = parseInt(poeni)

if (!isNaN(poeni)){
    ocenka = 0
    if (poeni>=0 && poeni<=50) ocenka = 5
    else if (poeni >50 && poeni<=60) ocenka = 6
    else if (poeni > 60 && poeni <= 70) ocenka = 7
    else if (poeni > 70 && poeni <= 80) ocenka = 8
    else if (poeni > 80 && poeni <= 90) ocenka = 9
    else if (poeni > 90 && poeni <= 100) ocenka = 10
    else document.write("Vnesen e pogresen broj na poeni!\n")

    if (ocenka){
        document.write("Studentot dobil ocenka: " + ocenka)
    }
}else {
    document.write("Ne ste vnele celosen broj!")
}


//todo: Zadaca 5 - Presmetuvanje stepen na priroden broj, n>=1 i realen broj x

var osnova = prompt("Vnesete ja osnovata na brojot: ")
var eksponent = prompt("Vnesete go stepenot na brojot: ")
osnova = parseInt(osnova)
eksponent = parseInt(eksponent)
var brojacc , yy;
if (!isNaN(osnova) && !isNaN(eksponent)){
    for (var brojacc = 1, yy=osnova; brojacc < eksponent; brojacc++){
        osnova*=yy;
    }
    document.write(yy + " ^ " + eksponent + " = " + osnova)
}else {
    document.write("Ne ste vnele broevi!")
}


//todo: Zadaaca 6 - Broevi vneseni od tastatura ke opredeli brojot na broevi sto se delivi so 3, pri delenjeto so 3 imaat ostatok 1, odnosno 2. Vnesuvat se broevi se dodeka ne se vnese znak

var n1 = 0, n2 = 0, n3 = 0
var brojce = prompt("Vnesete broj: ")
brojce = parseInt(brojce)
while (!isNaN(brojce)){
    if (brojce % 3 == 0){
        n1+=1
    }else if (brojce % 3 == 1){
        n2+=1
    }else {
        n3+=1
    }
    brojce = prompt("Vnesete broj: ")
    brojce = parseInt(brojce)
    document.write("Vnesovte <strong>" + n1 + "</strong> broevi koi imaat ostatok 0 pri delenje so 3 <br>")
    document.write("Vnesovte <strong>" + n2 + "</strong> broevi koi imaat ostatok 1 pri delenje so 3 <br>")
    document.write("Vnesovte <strong>" + n3 + "</strong> broevi koi imaat ostatok 2 pri delenje so 3 <br>")
}


//todo: Zadaca 7 - So vnesuvanje na broevi dodeka ne se vnese znak , ke go opredele brojot so max vrednost

var max = prompt("Vnesete prv broj: ")
max = parseInt(max)
var z = max
while(!isNaN(z)){
    if (z > max){
        max = z
    }
    z = prompt("Vnesete drug broj: ")
    z = parseInt(z)
}
document.write("Najgolemiot brojot sto go vnesovte e: " + max)


