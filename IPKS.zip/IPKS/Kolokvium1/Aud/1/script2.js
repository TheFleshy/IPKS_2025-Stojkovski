var string = prompt("Vnesete string: ")
var nizaBroevi = string.match(/\d+/g)

nizaBroevi.forEach((value) =>{
  value = parseInt(value)

    if(value >= 32){
        var asciiKod = String.fromCharCode(value)
        string = string.replace(value, asciiKod)
    }

})

alert(string)




var string = prompt("Vnesete prv string: ")
var string2 = prompt("Vnesete vtor string: ")
var string3 = prompt("Vnesete tret string: ")

string = string.split(' ')
string2 = string2.split(' ')
string3= string3.split(' ')

var najdolg = ''

string.forEach((word) =>{
  if (word.length > najdolg.length){
      najdolg = word
  }
})

string2.forEach((word) =>{
    if (word.length > najdolg.length){
        najdolg = word
    }
})

string3.forEach((word) =>{
    if (word.length > najdolg.length){
        najdolg = word
    }
})

alert(najdolg)




var karakteri = prompt("Vnesi karakteri");
karakteri = karakteri.split(';');

var recenica = prompt("Vnesi recenica");
var result = '';

for (let i = 0; i < recenica.length; i++) {
    var ch = recenica[i];
    var flag = true;


    for (let j = 0; j < karakteri.length; j++) {
        if (ch === karakteri[j]) {
            result += '\n';
            flag = false;
            break;
        }
    }


    if (flag) {
        result += ch;
    }
}

alert(result);
