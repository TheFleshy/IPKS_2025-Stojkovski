function change(){
    x = document.getElementById("demo")
    x.innerHTML = "Hello javaScript !!!"
}

// =================================================================
function myFunction(){
    y = document.getElementById("demo")
    y.style.color = "red"
}

// =================================================================
function functionn(){
    var x, text
    x = document.getElementById("numb").value
    if (isNaN(x) || x<1 || x>10){
        text = "Input not valid"
    }else {
        text = "Input OK"
    }
    document.getElementById("test").innerHTML = text;
}

// =================================================================
function getAtributes(){
    var u = document.getElementById("finki").href
    console.log("The value of the href attribute of the link is : " + u)

    var v = document.getElementById("finki").hreflang
    console.log ('The value of the hreflang attribute of the link is : '+v)

    var w = document.getElementById("finki").rel
    console.log('The value of the rel attribute of the link is : '+w)

    var x = document.getElementById("finki").target
    console.log('The value of the target attribute of the link is: ' + x)

    var y = document.getElementById("finki").type
    console.log("The value of the type attribute of the link is: " + y)
}

// =================================================================

function isPrime(){
    if (n===1) return false
    else if (n===2) return true
    else {
        for (let x = 2; x<n; x++){
            if (n % x === 0){
                return false;
            }
        }
        return true
    }
}

var n = Math.floor((Math.random() * 100) + 1)
console.log(n+ ', ' + isPrime(n))

// ==============================================================


var boldItems
window.onload = getBoldItems();

function getBoldItems() {
    boldItems = document.getElementsByTagName('strong')
}

function highlight(){
    for (var i=0; i<boldItems.length; i++){
        boldItems[i].style.color = "green"
    }
}

function returnToNormal(){
    for (var i=0; i<boldItems.length; i++){
        boldItems[i].style.color = "black"
    }
}

// ==============================================================

function getOptions(){
    var x = document.getElementById("mySelect")
    var txt1 = "No. of items: "
    var l = document.getElementById("mySelect").length
    txt1 = txt1+l
    for (let i=0; i<x.length; i++){
        txt1 = txt1 + "\n" + x.options[i].text
    }
    alert(txt1)
}

// ==============================================================


function volumeSphere(){
    var volume
    var radius = document.getElementById('radius').value
    radius = Math.abs(radius)
    volume = (4/3) * Math.PI * Math.pow(radius, 3)
    volume = volume.toFixed(4)
    document.getElementById('volume').value = volume
    return false
}
window.onload = document.getElementById('myForm').onsubmit = volumeSphere;


