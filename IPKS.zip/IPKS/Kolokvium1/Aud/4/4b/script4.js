/*
Напишете JavaScript функција која ќе трансформира објект во
листа од `[key,value]` парови

Влез:
{red: "#FF0000", green: "#00FF00", white: "#FFFFFF"}
Излез:
[["red", "#FF0000"], ["green", "#00FF00"], ["white", "#FFFFFF"]]
 */

 function key_value_pairs (obj){
     let keys = _keys(obj)
     let length = keys.length
     let pairs = Array(length)

     for (let i=0; i<length; i++){
         pairs[i] = [keys[i], obj[keys[i]]]
     }
     return pairs
 }

 function _keys(obj){
     if (!isObject(obj))
         return []
     let keys = []
     for (let key in obj)
         keys.push(key)
     return keys
 }

 function isObject(obj){
     let type = typeof obj
     return type === 'function' || type === 'object' && !!obj
 }

 console.log(key_value_pairs({red: "#FF0000", green: "#00FF00", white: "#FFFFFF"}))
s