/*
Напишете JavaScript програма која ќе ги прикаже сите атрибути
на даден објект
Влез:
let student = {
    name : "David Rayy",
    sclass : "VI",
    rollno : 12
};
Излез:
name,sclass,rollno
 */

let student = {
    name : "David Rayy",
    sclass : "VI",
    rollno : 12
};

function keys (student){
    if (!isObject(student))
        return []
    let keyss = []
    for (let key in student)
        keyss.push(key)
    return keyss
}

function isObject(student){
    let type = typeof student
    return type === 'function' || type === 'object' && !!student
}

document.write(keys({name: "#FF0000", sclass: "#00FF00", rollno: "#FFFFFF"}))