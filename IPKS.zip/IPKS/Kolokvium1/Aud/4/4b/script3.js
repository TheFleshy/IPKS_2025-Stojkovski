/*
Напишете JavaScript програма која во конзола ќе ги испечати
податоците за следните објекти (книга, автор и статус)
 */

let library = [
    {
        author: 'Bill Gates',
        title: 'The Road Ahead',
        readingStatus: true
    },
    {
        author: 'Steve Jobs',
        title: 'Walter Isaacson',
        readingStatus: true
    },
    {
        author: 'Suzanne Collins',
        title: 'The Final Book of The Hunger Games',
        readingStatus: false
    }
]

for (let i=0; i<library.length; i++){
    let book = "'" + library[i].title + "'" + ' by ' + library[i].author + "."

    if (library[i].readingStatus) {
        console.log("Already read" + book)
    }else {
        console.log("You still need to read" + book)
    }
}