/*
Напишете JavaScript програма која ќе гo избрише атрибутот rollno од следниот објект

let student = {
name : "David Rayy",
sclass : "VI",
rollno : 12
};
 */

let student = {
    name: "David Rayy",
    sclass: "VI",
    rollno: 12
}

console.log(student)
delete student.rollno
console.log(student)


