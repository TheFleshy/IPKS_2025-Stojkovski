/*
Напишете JavaScript програма која ќе пресметува периметар и плоштина на круг.

Забелешка: Креирајте два методи за периметар и плоштина.
Радиусот ќе биде даден како влез од корисникот

 */

function circle(radius) {
    this.radius = radius
    this.area = function () {
        return Math.PI * this.radius * this.radius
    }

    this.perimetar = function () {
        return 2 * Math.PI * this.radius
    }
}

let c = new circle(3)

document.write("Area = ", c.area().toFixed(2))
document.write("<br>")
document.write("Perimetar = ", c.perimetar().toFixed(2))


