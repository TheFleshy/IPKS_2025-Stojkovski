/*
Напишете JavaScript код кој ќе ги спои сите елементи во еден стринг

Влез:
myColor = ["Red", "Green", "White", "Black"];
Излез :
"Red,Green,White,Black"
"Red,Green,White,Black"
"Red+Green+White+Black"
 */

myColor = ["Red", "Green", "White", "Black"];
document.write(myColor.toString())
document.write("<br/>")
document.write(myColor.join());
document.write("<br/>")
document.write(myColor.join('+'));
