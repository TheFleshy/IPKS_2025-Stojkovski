/*
Напишете JavaScript код кој прима број како влез и вметнува „-“
помеѓу секои два парни броеви.
Влез:
025468
Излез :
0-254-6-8

 */

let num = window.prompt()
let str = num.toString()
let result = [str[0]];

for (let i=1; i<str.length; i++){
    if ((str[i-1] % 2 === 0) && (str[i]%2 === 0)){
        result.push('-', str[i])
    }else {
        result.push(str[i])
    }
}
document.write(result.join(''))

