/*
Напишете функција во JavaScript која како аргументи прима две
полиња, а како резултат враќа унија од двете полиња

Пример:
console.log(union([1, 2, 3], [100, 2, 1, 10]));
[1, 2, 3, 10, 100]
 */

function union (array1, array2){
    if ((array1 == null) && (array2 == null))
        return void 0

    let obj = {}

    for (let i = array1.length-1; i>= 0; i--){
        obj[array1[i]] = array1[i]
    }

    for (let i = array2.length-1; i>= 0; i--){
        obj[array2[i]] = array2[i]
    }

    let res = []
    for (let n in obj){
        if (obj.hasOwnProperty(n))
            res.push(obj[n])
    }
    return res
}

document.write(union([1,2,3], [100,2,1,10]))