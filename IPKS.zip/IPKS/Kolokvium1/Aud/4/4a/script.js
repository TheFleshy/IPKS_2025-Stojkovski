/*
    Напишете JavaScript функција која како аргумент прима поле и
параметар n, а како резултат ги враќа првите n елементи од
полето
10
Влез:
console.log(first([],3));
console.log(first([7, 9, 0, -2],3));
console.log(first([7, 9, 0, -2],6));
console.log(first([7, 9, 0, -2],-3));
Излез:
[]
[7, 9, 0]
[7, 9, 0, -2]
[]
 */

first = function (array, n){
    if (array == null)
        return void 0
    if (n == null)
        return array[0]
    if (n < 0)
        return []
    return array.slice(0, n)
}

console.log(first([7,9,0,-2]))
console.log(first([], 3))
console.log(first([7,9,0,-2], 3))
console.log(first([7,9,0,-2], 6))
console.log(first([7,9,0,-2], -3))
