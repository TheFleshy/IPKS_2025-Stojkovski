let counter = 0;
function dodavanje() {
    var username = document.getElementById("username").value
    var id = document.getElementById("id").value
    var width = document.getElementById("width").value
    var height = document.getElementById("height").value
    var color = document.getElementById("color").value

    if (!username || !id || !width || !height || !color){
        alert("Vnesi gi site podatoci")
        return
    }

    // for (let i=0; i<id.length; i++){
    //     var char = id[i]
    //     if ((char >= 'A' && char<= 'Z') || (char >= '0' && char <= '9')){
    //         alert("Id mora da bide od mali bukvi, ne smee da ima brojki")
    //         return;
    //     }
    // }
    if (/\d/.test(id)) {
        console.log("Contains a number");
    }


    if(isNaN(width) || isNaN(height) || width > 350 || height > 350){
        alert("Dolzinata i sirinata mora da se brojki i ne smeat da bidat pogolemi od 350px")
    }


    var cardContainer = document.getElementById("card")
    var card = document.createElement("div")

    card.style.display = "inline-block"
    card.style.margin = "5px"
    card.style.width = width + "px"
    card.style.height = height + "px"
    card.style.background = color

    let pixel = width*height*0.5
    if (color === "green") {
        pixel += 1000
    }

    card.innerHTML = "<p>" + "Id:" + id + "</p>" +
        "<p>" + "Width:" + width + "</p>" +
        "<p>" + "Height:" + height + "</p>" +
        "<p>" + "Color:" + color + "</p>" +
        "<p>" + "Vkupna suma:" + pixel + "</p>" +
        "<button onclick='Confirm(this)'>Sell</button>"

    cardContainer.appendChild(card)

}
function Confirm(button){
    let width = parseInt(card.querySelector("p:nth-child(2)").textContent.split(":")[1]);
    let height = parseInt(card.querySelector("p:nth-child(3)").textContent.split(":")[1]);
    let color = card.querySelector("p:nth-child(4)").textContent.split(":")[1].trim();
    let pixel = width*height*0.5
    if (color === "green") {
        pixel += 1000
    }
    let row = button.parentElement
    row.remove()
    counter+=pixel
    if (!isNaN(counter)){
        document.getElementById("counter").textContent = counter
    }
}